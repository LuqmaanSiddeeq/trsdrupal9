<?php

namespace Drupal\commerce_payment\Exception;

/**
 * Base exception for all payment gateway errors.
 */
class PaymentGatewayException extends \RuntimeException {}
